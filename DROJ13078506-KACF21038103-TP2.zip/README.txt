
Lancement du programme:

 -Pour lancer le programme il faut éxécuter le fichier index.html
 -Il faut s'identifier et s'authentifier dans les champs appropriés pour pouvoir effectuer des opérations.
        pour se connecter comme etudiant : codeMS = ss111111 password = ssss11111
        pour se connecter comme demonstrateur : codeMS = dd111111 password= dddd11111
        pour se connecter comme enseignant : codeMS = ee111111  password = eeee11111

Navigateurs supportés:

 -Google chrome
 -Firefox